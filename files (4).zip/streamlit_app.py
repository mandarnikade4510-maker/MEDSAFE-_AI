import streamlit as st

from med_logic import (
    KNOWN_DRUGS,
    assess_blood_pressure,
    assess_heart_rate,
    check_interactions,
    extract_medicines_from_prescription,
    get_medicine_options,
    get_side_effects,
    get_symptom_guidance,
    ai_error_message,
    ai_interaction_analysis,
    get_ai_key,
    label_to_name,
    online_interaction_check,
    online_name_suggestions,
    suggest_medicines,
)

# 1. Page configuration (must be the first Streamlit call)
st.set_page_config(page_title="MedSafe AI", page_icon="💊", layout="wide")
st.title("🛡️ MedSafe AI - Medical Safety Assistant")
st.caption("⚠️ For education only - not medical advice. In an emergency call your local emergency number (India: 112 / 108).")

SEVERITY_LABEL = {
    "critical": "🚨 CRITICAL",
    "severe": "🔴 SEVERE",
    "moderate": "🟠 MODERATE",
}


def show_level(level, message):
    """Show a vital-sign result in the right colour."""
    if level == "emergency":
        st.error(f"🚨 {message}")
    elif level == "warning":
        st.warning(f"⚠️ {message}")
    else:
        st.success(f"✅ {message}")


def show_interactions(findings, unrecognized, online=False):
    """Shared display for Tab 1 and Tab 2."""
    if unrecognized:
        st.warning(
            f"⚠️ Not in our database, so NOT checked: **{', '.join(unrecognized)}**. "
            "Ask a pharmacist about these."
        )
        for name in unrecognized:
            tips = suggest_medicines(name)
            if not tips and online:
                tips = online_name_suggestions(name)  # NLM RxNorm spelling suggestions
            if tips:
                st.info(f"Did you mean for **{name}**: {', '.join(tips)}?")

    if findings:
        worst = findings[0]["severity"]
        if worst in ("critical", "severe"):
            st.error("🚨 Serious interaction detected")
        else:
            st.warning("⚠️ Interaction detected")
        for f in findings:
            st.markdown(f"**{SEVERITY_LABEL[f['severity']]} - {f['drugs']}**  \n{f['message']}")
        st.info("💡 Talk to your doctor or pharmacist before taking these together.")
    elif unrecognized:
        st.warning(
            "Interactions could NOT be confirmed, because some medicines are not in the built-in database. "
            "Turn on the online library / AI explanation, or ask a pharmacist."
        )
    else:
        st.info(
            "No interaction found in our database for these medicines. "
            "This does not guarantee safety - please confirm with a doctor or pharmacist."
        )


def show_online_results(results, status, missing):
    """Display the optional online-library (FDA label) results."""
    st.subheader("🌐 Online medicine library")
    if status == "offline":
        st.warning("Online library not reachable (no internet access, or the service is busy). "
                   "Showing built-in database results only.")
        return

    if results:
        st.warning("⚠️ The official FDA drug label of one medicine mentions the other:")
        for r in results:
            st.markdown(f"**{r['drugs']}** - the FDA label for **{r['source']}** mentions **{r['mentioned']}**:")
            safe = r['excerpt'].replace('$', '\\$')
            st.caption(f"\u201c{safe}\u201d")
        st.info("A label mention is not a diagnosis of risk - it can be a warning, a dose note, or a class of drugs. "
                "Ask your doctor or pharmacist what it means for you.")
    else:
        st.info("No additional mentions found in FDA drug labels for these pairs. This does not guarantee safety.")

    if missing:
        st.caption(f"No FDA label found for: {', '.join(missing)} (many Indian brands are not in the US database).")
    st.caption("Source: openFDA drug labels (US). Labels may differ from Indian prescribing information.")


# 2. Tabs
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Medicine Interaction Checker",
    "Prescription OCR",
    "Symptom & Doubt Solver",
    "Side-Effect & Use Guide",
    "Emergency Risk Predictor",
])

# --- TAB 1: INTERACTION CHECKER ---
def read_ai_key():
    """AI key from the settings box, Streamlit secrets, or an environment variable."""
    typed = st.session_state.get("ai_key_input", "").strip()
    if typed:
        return typed
    try:
        secret = st.secrets.get("ANTHROPIC_API_KEY", "")
    except Exception:  # no secrets file on this machine
        secret = ""
    return (secret or get_ai_key() or "").strip() or None


def split_names(text):
    return [n.strip() for n in text.replace(";", ",").split(",") if n.strip()]


with tab1:
    st.header("Medicine Interaction Checker")
    st.caption("Type ANY medicine names. Checked against: built-in table (offline) \u2192 FDA drug labels (online) \u2192 AI explanation (optional).")

    options = get_medicine_options()
    ms_args = dict(
        label="1. Search and pick medicines (start typing, e.g. 'asp', 'war', 'cro'):",
        options=options,
        default=["Aspirin", "Warfarin"],
        placeholder="Type a medicine name...",
    )
    try:
        # Newer Streamlit: lets you also add a name that isn't in the list
        selected = st.multiselect(**ms_args, accept_new_options=True)
    except TypeError:
        selected = st.multiselect(**ms_args)

    extra_text = st.text_input(
        "2. Or type any other medicine names, separated by commas:",
        placeholder="e.g. Rifampin, Montair, Pantop D",
        key="extra_meds",
    )

    colA, colB = st.columns(2)
    use_online = colA.checkbox(
        "\U0001F310 Search the online medicine library (FDA drug labels + RxNorm)",
        value=True,
        help="Needs internet. If it is unavailable, the built-in database still works.",
    )
    use_ai = colB.checkbox(
        "\U0001F916 AI explanation for any medicine",
        value=True,
        help="Needs an Anthropic API key (see 'AI settings' below).",
    )

    with st.expander("\U0001F511 AI settings (optional)"):
        st.text_input(
            "Anthropic API key",
            type="password",
            key="ai_key_input",
            help="Only kept for this browser session. Never put a key in GitHub.",
        )
        st.caption(
            "Get a key at console.anthropic.com. For a deployed app, add ANTHROPIC_API_KEY under the app's Secrets "
            "instead. Without a key the app still works using the built-in table and FDA labels."
        )

    if st.button("Check Interactions", type="primary"):
        med_list, seen = [], set()
        for name in [label_to_name(x) for x in selected] + split_names(extra_text):
            if name.lower() not in seen:
                seen.add(name.lower())
                med_list.append(name)

        if len(med_list) < 2:
            st.warning("Please enter at least two medicines.")
        else:
            st.markdown("**Checking:** " + ", ".join(med_list))
            findings, unrecognized = check_interactions(med_list)
            show_interactions(findings, unrecognized, online=use_online)

            online_results = []
            if use_online:
                with st.spinner("Searching the online medicine library..."):
                    online_results, online_status, online_missing = online_interaction_check(med_list)
                st.divider()
                show_online_results(online_results, online_status, online_missing)

            if use_ai:
                st.divider()
                st.subheader("\U0001F916 AI explanation")
                with st.spinner("Asking the AI..."):
                    ai_text, ai_status = ai_interaction_analysis(
                        med_list, findings, online_results, api_key=read_ai_key()
                    )
                if ai_status == "ok":
                    st.markdown(ai_text)
                    st.caption("AI-generated and can be wrong. The built-in and FDA results above come from fixed sources - "
                               "if they disagree, trust the warning and ask a pharmacist.")
                elif ai_status == "no_key":
                    st.info("AI explanation is off because no API key is set. Open 'AI settings' above to add one.")
                else:
                    st.warning(ai_error_message(ai_status))

    with st.expander("Medicines our built-in database recognises"):
        st.write(", ".join(sorted(d.title() for d in KNOWN_DRUGS)))
        st.caption("Common brand names (Crocin, Dolo, Brufen, Advil, Prozac...) are also understood.")

# --- TAB 2: PRESCRIPTION OCR ---
with tab2:
    st.header("Prescription OCR Scanner")
    st.caption("Upload a clear prescription photo to detect medicines and check for interactions.")

    uploaded_file = st.file_uploader("Upload prescription image", type=["jpg", "jpeg", "png"])

    if uploaded_file:
        col1, col2 = st.columns(2)

        with col1:
            st.image(uploaded_file, caption="Uploaded prescription", use_container_width=True)

        with col2:
            if st.button("🔍 Extract & Analyze Prescription", type="primary"):
                with st.spinner("Reading prescription..."):
                    detected, raw_text = extract_medicines_from_prescription(uploaded_file)

                if detected:
                    st.success(f"Detected {len(detected)} medicine(s):")
                    for med in detected:
                        st.markdown(f"• **{med}**")
                    st.caption("OCR can make mistakes - verify against your prescription.")

                    st.divider()
                    if len(detected) >= 2:
                        st.subheader("Interaction check")
                        findings, unrecognized = check_interactions(detected)
                        show_interactions(findings, unrecognized)
                    else:
                        st.info("Only 1 medicine detected. Use Tab 1 to check it against other medicines you take.")
                else:
                    if raw_text.startswith("OCR Error"):
                        st.error(raw_text)
                    else:
                        st.warning("No known medicines were matched in the image.")
                    st.info("💡 Tips: good lighting, no flash glare, text in sharp focus, photo taken straight-on.")

                if raw_text:
                    with st.expander("View raw OCR text"):
                        st.text(raw_text)

# --- TAB 3: SYMPTOM GUIDE ---
with tab3:
    st.header("Symptom & Care Guidance")
    st.caption("Covers: chest pain, headache, fever, back pain, cough, cold, sore throat, stomach pain, diarrhea, vomiting, dizziness.")

    user_query = st.text_input(
        "Describe your symptom (e.g. headache, fever, cough):",
        key="symp_in",
        value="headache",
    )

    if st.button("Analyze Symptom", type="primary"):
        if user_query.strip():
            guidance = get_symptom_guidance(user_query)
            st.subheader(f"📋 {guidance['title']}")

            c1, c2 = st.columns(2)
            with c1:
                st.markdown("### 🟢 Self-care actions")
                for step in guidance["home_care"]:
                    st.write(f"• {step}")
            with c2:
                st.markdown("### 🚨 Warning signs (red flags)")
                for flag in guidance["red_flags"]:
                    st.write(f"⚠️ {flag}")

            st.divider()
            st.info(f"💡 **Next steps:** {guidance['recommendation']}")
        else:
            st.warning("Please enter a symptom.")

# --- TAB 4: SIDE EFFECTS & USE ---
with tab4:
    st.header("Side-Effect & Use Guide")
    st.caption("What a medicine is used for, its side effects, and safety precautions.")

    options4 = get_medicine_options()
    sb_args = dict(
        label="Search a medicine (start typing, e.g. 'ibu', 'met', 'cro'):",
        options=options4,
        index=options4.index("Ibuprofen"),
        key="side_in",
        placeholder="Type a medicine name...",
    )
    try:
        choice = st.selectbox(**sb_args, accept_new_options=True)
    except TypeError:
        choice = st.selectbox(**sb_args)
    med_input = label_to_name(choice) if choice else ""

    if st.button("Show Medicine Info", type="primary"):
        if med_input.strip():
            details = get_side_effects(med_input)
            st.subheader(f"💊 {details['name']}")

            st.info(f"📖 **Used for:** {details['uses']}")
            if not details["found"]:
                st.caption("ℹ️ Not in our database - showing general safety guidance only.")
                tips = suggest_medicines(med_input)
                if tips:
                    st.info(f"Did you mean: {', '.join(tips)}?")

            c1, c2 = st.columns(2)
            with c1:
                st.markdown("### 🟡 Common side effects")
                for e in details["common"]:
                    st.write(f"• {e}")
            with c2:
                st.markdown("### 🔴 Serious - get help")
                for e in details["serious"]:
                    st.write(f"⚠️ {e}")

            st.divider()
            st.info(f"💡 **Precautions:** {details['precautions']}")
        else:
            st.warning("Please enter a medicine name.")

# --- TAB 5: EMERGENCY RISK PREDICTOR (BP + HEART RATE) ---
with tab5:
    st.header("Emergency Risk Predictor")
    st.caption("Check blood pressure and heart rate against standard adult ranges.")

    hr = st.slider("Heart rate (BPM)", 30, 200, 75)
    c1, c2 = st.columns(2)
    sys_bp = c1.number_input("Systolic BP - top number (mmHg)", 60, 260, 120)
    dia_bp = c2.number_input("Diastolic BP - bottom number (mmHg)", 30, 160, 80)

    if st.button("Check Risk", type="primary"):
        st.subheader("Blood pressure")
        show_level(*assess_blood_pressure(int(sys_bp), int(dia_bp)))
        st.subheader("Heart rate")
        show_level(*assess_heart_rate(int(hr)))
        st.caption("Ranges are for adults at rest. Children, pregnancy and some conditions have different ranges.")

st.divider()
st.caption("MedSafe AI is a student/educational project. Always consult a qualified healthcare professional for medical decisions.")
